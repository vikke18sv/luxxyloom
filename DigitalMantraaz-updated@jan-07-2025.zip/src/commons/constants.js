export const product_category = [
    {id:1, value:"men's clothing", label:"men's clothing"},
    {id:2, value:"jewelery", label:"jewelery"},
    {id:3, value:"electronics", label:"electronics"},
    {id:4, value:"women's clothing", label:"women's clothing"}
]

export const sort_by_value = [
    {id:1, value:1, label: "Low to High"},
    {id:2, value:2, label: "High to Low"},
]